// Author: Daan van den Bergh
// Copyright: © 2022 Daan van den Bergh.

// Include all paths.
#include "../../include/vweb/vweb.h"

// No main required.
int main() {
	return 0;
}
