/*
 Author: Daan van den Bergh
 Copyright: © 2022 Daan van den Bergh.
*/

// Header.
#ifndef VWEB_SERVER_CONFIG_H
#define VWEB_SERVER_CONFIG_H


// Namespace vweb.
namespace vweb {

// ---------------------------------------------------------
// Server.

/*  @docs {
 *  @chapter: server
 *  @title: Config
 *  @description:
 *      Website server config.
 } */
struct ServerConfig {
    String  ip;                 // webserver ip.
    Int     port = -1;          // webserver port.
	Path  	cert;               // path to the certificate.
	Path  	key;                // path to the certificate key.
    String  pass;               // the password of the certificate.
	Path  	ca_bundle;          // path to the ca bundle (optional).
    Path    statics;            // path to static directory.
    Path    database;           // path to database.
    Bool    enable_2fa = true;  // 2FA required after sign up to activate account and after sign in.
    Int     max_threads = 25;   // max serve clients threads.
    Int     log_level = 1;      // log level [0...2].
    String  domain_name;        // domain name, e.g. "VInc".
    String  domain;             // domain url, e.g. "vandenberghinc.com".
    vlib::smtp::Client::ConstructArgs smtp; // the smtp client args.
    
    // Load from file path.
    /*  @docs {
     *  @chapter: server
     *  @title: Load Config
     *  @description:
     *      Load the server configuration from a json file.
     *
     *      Take a look at the example for the json keys.
     *  @usage:
     *      // The json may end with a , after the last value.
     *      // The json may contain comments before the keys, but not after the last value.
     *      // The string $BASE will be replaced in file paths with the base path of parameter "path".
     *      {
     *          "server": {
     *              "ip": "*",
     *              "port": 443,
     *              "static": "$BASE/static",
     *              "database": "$BASE/.db",
     *              "database": "$BASE/.db",
     *              "enable_2fa": true,
     *              "max_threads": 25,
     *              "log_level": 1,
     *          },
     *          "domain": {
     *              "name": "My Company",
     *              "domain": "mycompany.com",
     *          },
     *          "tls": {
     *              "cert": "$BASE/.tls/cert.pem",
     *              "key": "$BASE/.tls/cert.pem",
     *              "pass": "",
     *          },
     *          "smtp": {
     *              "host": "smtp.domain.com",
     *              "port": 465,
     *              "email": "my@email.com",
     *              "password": "mypass",
     *              "domain": "",
     *              "dkim": "", // dkim private key data.
     *              "timeout": 5 * 1000,
     *              "debug": false,
     *          },
     *      }
     } */
    static
    ServerConfig load(const Path& path) {
        Path base = path.base();
        Json json = Json {
            {"server", Json {
                {"ip", "*"},
                {"port", -1},
                {"static", ""},
                {"database", ""},
                {"enable_2fa", true},
                {"max_threads", 25},
                {"log_level", 1},
            }},
            {"domain", Json {
                {"name", ""},
                {"domain", ""},
            }},
            {"tls", Json {
                {"cert", ""},
                {"key", ""},
                {"pass", ""},
				{"ca_bundle", ""},
            }},
            {"smtp", Json {
                {"host", ""},
                {"port", 465},
                {"email", ""},
                {"password", ""},
                {"domain", ""},
                {"dkim", ""},
                {"timeout", 5 * 1000},
                {"debug", false},
            }},
        };
        json.concat_r(Json::load(path));
        Json& server = json["server"].asj();
        Json& domain = json["domain"].asj();
        Json& tls = json["tls"].asj();
        Json& smtp = json["smtp"].asj();
        return {
            .ip = server["ip"].ass(),
            .port = server["port"].asi(),
            .cert = tls["cert"].ass().replace_r("$BASE", base),
            .key = tls["key"].ass().replace_r("$BASE", base),
            .pass = tls["pass"].ass(),
			.ca_bundle = tls["ca_bundle"].ass().replace_r("$BASE", base),
            .statics = server["static"].ass().replace_r("$BASE", base),
            .database = server["database"].ass().replace_r("$BASE", base),
            .enable_2fa = server["enable_2fa"].asb(),
            .max_threads = server["max_threads"].asi(),
            .log_level = server["log_level"].asi(),
            .domain_name = domain["name"].ass(),
            .domain = domain["domain"].ass(),
            .smtp = {
                .host = smtp["host"].ass(),
                .port = smtp["port"].asi(),
                .email = smtp["email"].ass(),
                .pass = smtp["password"].ass(),
                .domain = smtp["domain"].ass(),
                .dkim = smtp["dkim"].ass().replace_r("$BASE", base),
                .timeout = smtp["timeout"].asi(),
                .debug = smtp["debug"].asb(),
            }
        };
    }
};

// ---------------------------------------------------------
// End.

};         // End namespace vweb.
#endif     // End header.

